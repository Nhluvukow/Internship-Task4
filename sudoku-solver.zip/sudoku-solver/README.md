# Sudoku Solver

A Python program to solve Sudoku puzzles using backtracking.

## Features
- Solves standard 9x9 Sudoku puzzles.
- Displays the solution or indicates if no solution exists.

## Usage
Run the program to solve a predefined Sudoku puzzle.